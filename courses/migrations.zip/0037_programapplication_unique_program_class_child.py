from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):

    dependencies = [
        ('courses', '0036_remove_programapplication_unique_program_class_child'),
    ]

    operations = [
        migrations.AddField(
            model_name='programapplication',
            name='program_class',
            field=models.ForeignKey(
                to='courses.programclass',
                on_delete=django.db.models.deletion.CASCADE,
                related_name='applications',
                null=True,
                blank=True,
            ),
        ),
    ]