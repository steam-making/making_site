from django.db import migrations

def migrate_target_code_to_fk(apps, schema_editor):
    Program = apps.get_model("courses", "Program")
    Target = apps.get_model("courses", "Target")

    code_to_id = {}
    for target in Target.objects.all():
        code_to_id[target.code] = target.id

    for program in Program.objects.all():
        # 기존 문자열 값 (예: "kid", "elem", "adult"...)
        code = program.__dict__.get("target")  # 마이그레이션 시점에서는 FK → CharField 가 남아 있을 수도 있음
        if code and code in code_to_id:
            program.target_id = code_to_id[code]
            program.save(update_fields=["target_id"])
        else:
            # 매핑이 없으면 null 로 두기
            program.target_id = None
            program.save(update_fields=["target_id"])

class Migration(migrations.Migration):

    dependencies = [
        ("courses", "0019_target_alter_program_target"),
    ]

    operations = [
        migrations.RunPython(migrate_target_code_to_fk, reverse_code=migrations.RunPython.noop),
    ]
